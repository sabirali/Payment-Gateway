<?php
$requestsite = "https://test.instamojo.com/api/1.1/payment-requests/";

$instamojoapikey = "X-Api-Key:bcd152ed829f4c28a5eee7f244ef46bc";
$instamojoauthtoken = "X-Auth-Token:2f9a959aec861b11a469e7548e3fbebd";
$salt = "b590d3e3674541bfb45d497a765dcd89";

$redirect_url = "http://localhost/Instamojo-php-curl/success";

$webhook = "http://ec2-52-66-46-3.ap-south-1.compute.amazonaws.com/admin08jun16/test-instamojo-webhook.php";


$servername = "localhost";
$username = "root";
$password = "jos@123";
$dbname = "Instamojo-php-curl";

//mail
$smtpserver = 'smtp.gmail.com';
$usernametosend = "dhrumil.joshi72247@gmail.com";
$mailpassword = "RS@alisabirali4489";
$mailsendfrom = "sabirali@jobsonsight.co.in";
$namesendfrom = "no-reply";
$mailreplyto = "test@gmail.com";
$usernamereplyto = "no-reply";
$location = "Asia/Calcutta";

?>